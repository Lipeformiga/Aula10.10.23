package Matriz;

import java.util.Scanner;

public class atividade5 {

	public static void main(String [] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int contador = 0;
		int matriz[][] = new int [4][4];
		
		for (int i=0;i<0;i++) {
			for (int x=0;x<0;x++) {
				System.out.println("escreva os números das matrizes"+ "["+ (i+1) +"]"+ "["+ (x+1) +"]");
				contador++;
				
				if ( contador == 1) {
					
				}
			}
		}
	}
}